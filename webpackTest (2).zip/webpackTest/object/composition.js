/**
 * 합성
 *  : 필요한 기능을 직접 구현하는 것이 아니라 필요한 기능을 구현하고 있는 객체와 연결해서 기능을 사용 하는 것.
 *  기능을 구현하고 있는 객체와 기능을 사용하는 객체 간의 관계 == 합성 관계
 *  
 *  특정 객체가 가진 기능을 재사용하고 싶은 경우, 동적 바인딩 기능 구현, 기능을 직접 구현X 외부에 구현된 객체를 연결해서 사용.
 *  
 *  상속이 사용하는 경우 : 기능이 필요하다고 (x) IS-A 관계 (O) 부모 기능을 확장하기 위해(O)
 */

class RollingBanner{ // Rolling Banner 태그만 다룸. rolling Banner에 있어서 다음 data가 무엇인지에 대한 정보만 담김.
	
	constructor(selector, effect){ // effect 가 합성되는 부분.
		this.$_banner = $(selector).children("img"); 
		this.$_currentIndex = 0;
		this._timeID = -1;
		this._playSpeed = playSpeed;
        this._rollingSpeed = rollingSpeed;

        // 롤링효과 인스턴스를 저장할 변수
        this._effect = effect;
        this._bannerWidth = 0;
	}
	_start(){
		
	}
}

class TBRollingEffect{ // Rolling Banner의 움직임(효과)만 다룸.
	constructor(){
		// no instacne.
	}
	effect(info){
		info.$inBanner.css({
			top:-info.bannerHeight,
            opacity:0
            });
		
	}
}