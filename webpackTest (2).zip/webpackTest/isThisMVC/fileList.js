/**
 *  Main View 컨트롤러가 필요할 것 같은데..?
 */

class FileList { 
	// api 결과를 받아와서 fileList를 저장함.
	constructor(apiResponse){
	//	this.$_targetView;
		this._uploadedFile = apiResponse;
		this.listeners = {}; // 현재 리스너 없음.
	}
	
	deleteFileEvents(fileId){
		this._uploadedFile.splice(fileId,1);
		// fileListView로 splice한 결과를 전달해줌.
	}
	addFileEvents(file){
		this._uploadedFile.push(file);
	}
}

class FileListView { // 받아온 결과를 가지고 dom을 화면에 보여주는 객체.
	constructor(selector, fileModel){ // dom
		this.$_dom = $(selector);
		_init(fileModel);
	}
	_init(fileModel){
		// create dom initially here
		// add events...
	}
	deleteDom(fileId){
		// remove dom.
	}
	addDom(fileId){
		// add dom.
	}
}

class subMenuView{ // 우클릭 이벤트 감지시 떠야 하는 화면
	// mainView, ZipView 둘다 필요함.
	// 다만 ZipView 에서는 download만 구현해야 함.
	// 여기서 삭제 요청 class 에게 삭제 정보를 넘겨준다.
	constructor(){
		this.$_subMenu // 우클릭 이벤트 발생시 보여줄 dom
		this._delete = true; // delete dom? 혹은 선택 가능 true, false 중 뭐가 담길지 모르겠음. 
		this._download; /* = dom object*/
	}
}