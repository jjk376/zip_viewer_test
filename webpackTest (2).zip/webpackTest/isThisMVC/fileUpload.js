/**
 * 
 */
class DropEvent{
	constructor(event){
		this._event = event;
	}	
	// drop한 파일 다루는 객체.
	// 사실 여기서 하는 일은 window.event.preventDefault() 해주고... drop zone 에 맞게 drop 됐는지...
	
	getFiles(){
		// drop한 이벤트를 원하는 결과물로 파싱 해주는 과정을 여기서 함.
		return files; // files == array타입.
	}

	
}
class FileUpload{
	constructor(){
		this._uploadQueue;  
	}
	getFile(fileArray){
		// dropEvent는 
		// dropEvent -> file -> Queue.
	}
	fileQueuePush(){
		
	}
	fileQueuePop(){ 
		
	}
	ajaxUpload(){
		// upload using uploadQueue
	}
}

class UploadProgressView{
	// Dom 만들고 지우고...
	constructor(select){
		this.$_rootDom = $(select);
		// rootDom의 자식노드는 최초엔 없다.
		// FileUpload 에서 filePop() 될때 마다 dom이 하나씩 추가된다. 
	}
}