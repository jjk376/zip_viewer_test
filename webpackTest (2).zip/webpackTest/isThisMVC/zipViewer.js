/**
 * 
 */

class ZipFile{ //Model 구현.
	constructor(apiResponse){
		// apiResponse에 맞게 첫 노드 초기화
		// apiResponse에 맞게 다음 노드 초기화
		this._root = root;  // root 는 FileNode 타입.
		this._header = root; // 
	}
	ajaxExplore(){
		// ajax요청을 때려서 받아온다.
	}
}

class FileNode{
	constructor(apiResponse){
		this._fileData; // 파일에 대한 정보만 담김.
		this._fileParent; // 이게 필요할까? 
		this._fileChildren; // 파일의 자식들. 배열형. 자식 없으면 null?
		this._isExploered; // 탐색되었는가.
	}
}

class FileListView {
	// dom을 다룸.
}

class FileTreeView {
	// dom을 다룸
}

class ZipFileController {
	// View 에서 발생된 컨트롤 이벤트를 받아서 ZipFile Model로 header 값을 넘겨 준다.
}