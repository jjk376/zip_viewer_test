/**
 * entry files 
 */

import Vehicle from "../src/model/Vehicle";
//let Vehicle = require("../src/model/Vehicle");
let tico = new Vehicle('tico', 50);
console.log(Vehicle.staticMethod());
console.dir(tico);